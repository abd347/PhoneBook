# <a href="http://brianmatovu.com/android-sqlite-database-tutorial/">PhoneBook</a>
Android SQLite Tutorial

It is source code to this article <a href="http://bmatovu.com/android-sqlite-database-tutorial/">Android SQLite Tutorial</a>. 
Please visit it for an explanation of how this code works.
